#1/usr/bin/env python3
import matplotlib.pyplot as plt


lidar_1 = open("/home/adebolt/Downloads/catkin_ws/src/project/scripts/data.txt", 'r')

lidar_1_data = lidar_1.read()

lidar_1_data = lidar_1_data.split("\n")[1:-1]

x = []
y = []
for pt in lidar_1_data:
    pt = pt.split(" ")
    x.append(float(pt[0]))
    y.append(float(pt[1]))

plt.scatter(x, y)
plt.show()
