import tf
import rospy
import numpy as np
from sklearn.cluster import DBSCAN
from math import cos, sin, atan, atan2, sqrt, pi, degrees

from std_msgs.msg import Bool
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan, Range, Imu


# TASK DESCRIPTION
# start inside box
# find entrance location
# drive through entrance
# get to position where we can see the tag if we turn
# center robot on tag
# take range reading
# drive x distance
# if bot is missing add control for relative left right speed based on tag position on camera

def dist(pt1, pt2):
    return sqrt((pt1[0]-pt2[0])*(pt1[0]-pt2[0]) + (pt1[1]-pt2[1])*(pt1[1]-pt2[1]))

class Chassis:
    def __init__(self):
        print("input aruco tag number")
        self.tag_number = input()
        self.init = True
        self.lidar_data = []
        # data for use to get robot out of starting location
        self.angle_to_turn_to_wall = -1
        self.distance_to_wall = -1
        self.distance_to_get_out = -1

        # basic sensor information gathered
        self.aruco_dist = -1
        self.sonar_distance = -1
        self.pose = -1
        self.current_angle = -1

        # sensor subs
        # self.camera_sub = rospy.Subscriber("cam", Bool, callback=self.recive_camera_data) # TODO make a publisher that returns the tag number and angle
        self.lidar_sub = rospy.Subscriber("scan", LaserScan, callback=self.read_lidar)
        self.encoder_sub = rospy.Subscriber("pose", Odometry, callback=self.pose_callback) # if this also gives angle of robot no need for imu topic
        self.sonar_sub = rospy.Subscriber("sonar", Range, callback=self.recive_sonar_data)

        # motor pub
        self.cmd_vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        self.cmd_vel_message = None

        # start motor run
        self.running = False
        self.run_robot()

    def run_robot(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown() and self.running and not self.cmd_vel_message == None:
            self.cmd_vel_pub.publish(self.cmd_vel_message)
            rate.sleep()

    def read_lidar(self, data):
        if self.init:
            # gather and throw out first few datapoints
            while len(self.lidar_data) < 1000:
                self.lidar_data.append(0)
            self.lidar_data = []
            self.init = False
        else:
            ranges = data.ranges
            angl = [data.angle_min + data.angle_increment*i for i in range(len(data.ranges))]

            for pt in range(len(ranges)):
                # add data if its ranges is good, and there arent enough points yet
                if len(self.lidar_data) < 2000 and ranges[pt] > .05 and ranges[pt] < 3:
                    self.lidar_data.append([ranges[pt], angl[pt]])


    # the msg will either be False if the correct aruco isnt in camera
    def output_information(self):
        print(f"Pose:{self.pose}, Sonar Dist:{self.sonar_distance}, imu angle:{self.current_angle}")

    # def recive_imu_data(self, data):
    #     print("imu", data)
    #     self.current_angle = data

    def recive_camera_data(self, data):
        print("cam", data)
        if data.data == self.tag_number:
            self.aruco_dist = self.sonar_distance

    def recive_sonar_data(self, data):
        print("sonar", data)
        self.sonar_distance = data.range

    def pose_callback(self, data):
        orientation_recived = data.pose.pose.orientation
        orientation_list = [orientation_recived.x, orientation_recived.y, orientation_recived.z, orientation_recived.w]
        (roll, pitch, yaw) = tf.transformations.euler_from_quaternion(orientation_list)# yaw -pi, pi 
        self.pose = [data.pose.pose.position.x, data.pose.pose.position.y, degrees(yaw+pi)]

    def command_vel(self, forward, rotational):
        twist = Twist()
        twist.linear.x = forward
        twist.linear.y = 0
        twist.linear.z = 0

        twist.angular.x = 0
        twist.angular.y = 0
        twist.angular.z = rotational

        self.cmd_vel_message = twist

    def find_main_wall(self):
        if not len(self.lidar_data) == 2000:
            print("not enough lidar data", len(self.lidar_data))
        else:
            points = [[cos(data[1])*data[0], sin(data[1])*data[0]] for data in self.lidar_data]
            dbscan = DBSCAN(eps=.2, min_samples=20)
            points = np.array(points)
            labels = dbscan.fit_predict(points)
            filtered_points = points[labels != -1]
            points = filtered_points.tolist()
            points = sorted(points, key=lambda point:atan2(point[0], point[1]))
            for pt in points:
                print(pt[0], pt[1])

            exit()
            # 4 quadrants
            quadrants = [[], [], [], []]
            gap = []
            max_gap = -1
            for pt, point in enumerate(points):
                next = (pt+1) % len(points)
                gap_between = dist(points[pt], points[next])
                if max_gap < gap_between:
                    max_gap = gap_between
                    gap = [pt, next]

                if point[0] > 0 and point[1] > 0:
                    quadrants[0].append(pt)
                elif point[0] > 0 and point[1] < 0:
                    quadrants[1].append(pt)
                elif point[0] < 0 and point[1] > 0:
                    quadrants[2].append(pt)
                else:
                    quadrants[3].append(pt)

            corner_dists = [0,0,0,0]
            corners = [0,0,0,0]
            for quad in range(4):
                for pt in quadrants[quad]:
                    if corner_dists[quad] < dist(points[pt], [0,0]):
                        corners[quad] = pt
                        corner_dists[quad] = dist(points[pt], [0,0])
            corners = sorted(corners)
            print(corners)
            ends = [0,0]
            if gap[0] < gap[1]:
                for pt in range(4):
                    if corners[pt] < gap[0]:
                        ends[0] = corners[pt]
                        ends[1] = corners[(pt+2)%4]
            else:
                print("ERROR HERE")

            print(gap, ends, max_gap)

            if ends[0] > gap[0]:
                walls = [points[ends[0]:-1] + points[0:gap[0]], points[gap[1]:ends[1]]]
            elif ends[1] < gap[1]:
                walls = [points[ends[0]:gap[0]], points[gap[1]:-1] + points[0:ends[1]]]
            else:
                walls = [points[ends[0]:gap[0]], points[gap[1]:ends[1]]]
            print("gap walls corneres:", walls[0][0], walls[0][-1], walls[1][0], walls[1][-1])
            
            long_wall = walls[0] if dist(walls[0][0], walls[0][-1]) > dist(walls[1][0], walls[1][-1]) else walls[1]
            short_wall = walls[0] if not long_wall == walls[0] else walls[1]

            # find angle to turn, and both dist to drive
            x = np.array([data[0] for data in long_wall])
            y = np.array([data[1] for data in long_wall])
            A = np.vstack([x, np.ones(len(x))]).T
            m, c = np.linalg.lstsq(A, y, rcond=None)[0]
            self.angle_to_turn_to_wall = atan(m)%(pi/2) # number of degrees to turn in radians
            point = long_wall[0] if long_wall == walls[1] else long_wall[-1]
            print("pt to find orientation", point)

            if point[0] > 0 and point[1] > 0:
                self.angle_to_turn_to_wall += 0
            elif point[0] < 0 and point[1] > 0:
                self.angle_to_turn_to_wall += pi/2
            elif point[0] > 0 and point[1] < 0:
                self.angle_to_turn_to_wall -= pi/2
            elif point[0] < 0 and point[1] < 0:
                self.angle_to_turn_to_wall += pi

            print("angle to turn", degrees(self.angle_to_turn_to_wall))

            min_long, min_short = -1, -1
            for pt in long_wall:
                dist_to_pt = dist(pt, [0,0])
                min_long = min_long if min_long > dist_to_pt else dist_to_pt

            for pt in short_wall:
                dist_to_pt = dist(pt, [0,0])
                min_short = min_short if min_short > dist_to_pt else dist_to_pt

            self.distance_to_wall = min_long - .5 - .05 # dist between center and wall - half the opening - (robot len / 2)
            self.distance_to_get_out = min_short + .5 # dist to the opening + a bit extra
            exit()

class Chassis_Controller:
    def __init__(self):
        self.chassis = Chassis()

    def wait_lidar(self):
        while len(self.chassis.lidar_data) < 2000:
            None
        self.chassis.find_main_wall()
        print(degrees(self.chassis.angle_to_turn_to_wall), self.chassis.distance_to_wall, self.chassis.distance_to_get_out)

    # in randians
    def turn_for_angle(self, angle):
        # TODO turn robot for angle radians
        current_angle = self.chassis.current_angle
        wanted_angle = current_angle + angle
        if angle < 0:
            print("turning neg degrees")
            self.chassis.command_vel(0, 1)
        else: 
            print("turning pos degrees")
            self.chassis.command_vel(0, -1)

    # in meters
    def drive_for_distance(self, distance):
        # TODO might need a better controller, also make sure to avg left right encoders for the var encoder_ticks so that we are getting correct dist
        None

def main():
    rospy.init_node("aDrive")
    rospy.loginfo("STARTED AUTO DRIVE")
    chassis_controller = Chassis_Controller()
    chassis_controller.wait_lidar()
    chassis_controller.chassis.output_information()
    rospy.spin()


if __name__ == '__main__':
    main()

