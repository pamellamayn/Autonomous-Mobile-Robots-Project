#!/usr/bin/env python3
import rospy
from std_msgs.msg import Int32

def publisher():
    rospy.init_node('input_publisher', anonymous=True)
    pub = rospy.Publisher('numbers', Int32, queue_size=10)

    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
       try:
           number = int(input('Enter an Aruco Value: '))
           pub.publish(number)
       except:
           rospy.logwarn('Invalide AruCo')

       rate.sleep()

if __name__ == '__main__':
    try:
        publisher()
    except rospy.ROSInterruptException:
        pass
