#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32
from std_msgs.msg import Int32
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
import copy
import time
# def euler_from_quaternion(x, y, z, w):Convert a quaternion into euler angles (roll, pitch, yaw) roll is rotation around x in radians (counterclockwise) pitch is rotation around y in radians (counterclockwise)

# Global variables to store the current values of alpha, delta, and distance traveled
alpha_error = 5.0
delta_value = 5.0
distance_traveled = 0.0
aruco_id = 0
orientation_quaternion = 0.0
aruco_input = 0

def input_callback(msg):
    global aruco_input
    aruco_input = msg.data

def aruco_callback(msg):
    global aruco_id
    aruco_id = msg.data

def alpha_callback(msg):
    global alpha_error
    alpha_error = msg.data

def delta_callback(msg):
    global delta_value
    delta_value = msg.data

def odom_callback(msg):
    global distance_traveled
    # Extracting orientation information from odometry message
    orientation_quaternion = msg.pose.pose.orientation
    orientation_list = [orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w]
    _, _, yaw = euler_from_quaternion(orientation_list)

    # Assuming the robot is moving in the x direction, update distance traveled
    distance_traveled = msg.pose.pose.position.x

def align_to_aruco():
    rospy.init_node('align_to_aruco', anonymous=True)
    cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)

    #Subscribers for alpha, delta, and odometry messages
    rospy.Subscriber('alpha_error', Float32, alpha_callback)
    rospy.Subscriber('marker_distance', Float32, delta_callback)
    rospy.Subscriber('aruco_id', Float32, aruco_callback)
    rospy.Subscriber('pose', Odometry, odom_callback)
    rospy.Subscriber('numbers', Int32, input_callback)

    twist = Twist()
    rate = rospy.Rate(40)

    # Adjust this value to set the desired angular velocity for orientation adjustment
    angular_velocity = 0.15
    while delta_value > 0.50:
        while not rospy.is_shutdown():
            print(f'Aruco Id: {aruco_id}')
            if -1.0 < alpha_error < 1.0 and aruco_id==1:
                twist.angular.z = 0.0  # Stop adjusting orientation
                break
            elif aruco_id != 1:
                twist.angular.z = angular_velocity
            else:
                # Adjust the orientation with a constant angular velocity
                 twist.angular.z = -angular_velocity if alpha_error > 0 else angular_velocity

            cmd_vel_pub.publish(twist)
            rate.sleep()

        # twist.linear.x = 0  # Stop the robot
        twist.angular.z = 0  # Stop adjusting orientation
        cmd_vel_pub.publish(twist)
        rospy.sleep(0.75)
        # Print the final alignment error and current value of delta
        print('\n-----------------------------------------------')
        print(f"Final Alignment Error: {alpha_error} degrees")
        print(f"Current Value of Delta: {delta_value} degrees")
        print('------------------------------------------------\n')

#       Continue moving forward using odometry feedback
        target_distance = 0.08  # Set the desired distance to 30 centimeters
        linear_velocity = 0.20
        twist.linear.x = linear_velocity
        first_distance = copy.deepcopy(distance_traveled)
        while (-target_distance <  (distance_traveled - first_distance) < target_distance) and not rospy.is_shutdown() and delta_value > 0.50:
            cmd_vel_pub.publish(twist)
            rate.sleep()
        
        twist.linear.x = 0  # Stop the robot
        cmd_vel_pub.publish(twist)

#       Print the distance traveled and current value of delta
        print('\n--------------------------------------------')
        print(f"Distance Traveled: {distance_traveled} meters")
        print(f"Current Value of Delta: {delta_value} degrees")
        print('----------------------------------------------\n')
        rospy.sleep(1)
   
#       looking for 4 **************************************************************************************************
    print('looking for 4')
    while not rospy.is_shutdown():
        if -1.0 < alpha_error < 1.0 and aruco_id == 4:
            twist.angular.z = 0.0  # Stop adjusting orientation
            break
        elif (aruco_id == 20 or aruco_id ==10) and (-3 < alpha_error <3) :
           twist.angular.z = 0.0
           break
        elif aruco_id != 4:
           twist.angular.z = -angular_velocity
        else:
            # Adjust the orientation with a constant angular velocity
            twist.angular.z = -angular_velocity #if alpha_error > 0 else angular_velocity
        cmd_vel_pub.publish(twist)
        rate.sleep()
    print("1")
    # twist.linear.x = 0  # Stop the robot
    twist.angular.z = 0  # Stop adjusting orientation
    cmd_vel_pub.publish(twist)
    rospy.sleep(1)

    if aruco_id !=10 and aruco_id !=20:
        #align robot to exit
        twist.angular.z = angular_velocity
        print(f'Angular Velocity: {angular_velocity}')
        print('publish twist')
        start_time = time.time()
        while time.time() - start_time < 4:
    	    cmd_vel_pub.publish(twist)
        #rospy.sleep(12.0)
        print('after sleep')
        twist.angular.z = 0
        cmd_vel_pub.publish(twist)
        rospy.sleep(0.75)
        print('2')

    #move out of rooom
        target_distance = 1.3
        twist.linear.x = linear_velocity
        first_distance = copy.deepcopy(distance_traveled)
        while (-target_distance <  (distance_traveled - first_distance) < target_distance) and not rospy.is_shutdown():
            cmd_vel_pub.publish(twist)
            rate.sleep()
            print('\n------------------------------------------------------------')
            print(f'Distance minus first: {distance_traveled - first_distance}')
            print(f'First Distance: {first_distance}')
            print(f'Distance Traveled: {distance_traveled}')
            print(f'Delta Value: {delta_value}')
            print('--------------------------------------------------------------\n')

        twist.linear.x = 0  # Stop the robot
        cmd_vel_pub.publish(twist)
        rospy.sleep(1)

    #find aruco given
    while delta_value > 0.50:
        while not rospy.is_shutdown():
            if aruco_input == 10:
               forbid_aruco = 20
            elif aruco_input == 20:
               forbid_aruco = 10
            else:
               forbid_aruco = 0
            
            if aruco_input != forbid_aruco:
                print(f'Aruco Input: {aruco_input}')
                if -1.0 < alpha_error < 1.0 and aruco_id==aruco_input:
                    twist.angular.z = 0.0  # Stop adjusting orientation
                    break
                elif aruco_id != aruco_input:
                    twist.angular.z = -angular_velocity
                else:
                    # Adjust the orientation with a constant angular velocity
                    twist.angular.z = -angular_velocity if alpha_error > 0 else angular_velocity
                    #pass

                cmd_vel_pub.publish(twist)
                rate.sleep()

        # twist.linear.x = 0  # Stop the robot
        twist.angular.z = 0  # Stop adjusting orientation
        cmd_vel_pub.publish(twist)
        rospy.sleep(0.75)
        # Print the final alignment error and current value of delta
        print('\n-----------------------------------------------')
        print(f"Final Alignment Error: {alpha_error} degrees")
        print(f"Current Value of Delta: {delta_value} degrees")
        print('------------------------------------------------\n')

#       Continue moving forward using odometry feedback
        target_distance = 0.08  # Set the desired distance to 30 centimeters
        linear_velocity = 0.25
        twist.linear.x = linear_velocity
        first_distance = copy.deepcopy(distance_traveled)
        while (-target_distance <  (distance_traveled - first_distance) < target_distance) and not rospy.is_shutdown() and delta_value > 0.50:
            cmd_vel_pub.publish(twist)
            rate.sleep()
        #print('\n------------------------------------------------------------')
        #print(f'Distance minus first: {distance_traveled - first_distance}')
        #print(f'First Distance: {first_distance}')
        #print(f'Distance Traveled: {distance_traveled}')
        #print(f'Delta Value: {delta_value}')
        #print('--------------------------------------------------------------\n')

        twist.linear.x = 0  # Stop the robot
        cmd_vel_pub.publish(twist)

#       Print the distance traveled and current value of delta
        print('\n--------------------------------------------')
        print(f"Distance Traveled: {distance_traveled} meters")
        print(f"Current Value of Delta: {delta_value} degrees")
        print('----------------------------------------------\n')
        rospy.sleep(1)


    #hit tag
    target_distance = 0.2
    twist.linear.x = linear_velocity
    #first_distance = copy.deepcopy(distance_traveled)
    #while (-target_distance <  (distance_traveled - first_distance) < target_distance) and not rospy.is_shutdown():
    start_time = time.time()
    while time.time() - start_time < 2:
        cmd_vel_pub.publish(twist)
    twist.linear.x = 0  # Stop the robot
    cmd_vel_pub.publish(twist)
    rospy.sleep(1)


    # Print the final alignment error and current value of delta
    print('\n-----------------------------------------------')
    print(f"Final Alignment Error: {alpha_error} degrees")
    print(f"Current Value of Delta: {delta_value} degrees")
    print('------------------------------------------------\n')

if __name__ == '__main__':
    try:
        align_to_aruco()
    except rospy.ROSInterruptException:
        pass
