#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
# def euler_from_quaternion(x, y, z, w):Convert a quaternion into euler angles (roll, pitch, yaw) roll is rotation around x in radians (counterclockwise) pitch is rotation around y in radians (counterclockwise)

# Global variables to store the current values of alpha, delta, and distance traveled
alpha_error = 5.0
delta_value = 0.0
distance_traveled = 0.0

def alpha_callback(msg):
    global alpha_error
    alpha_error = msg.data

def delta_callback(msg):
    global delta_value
    delta_value = msg.data

def odom_callback(msg):
    global distance_traveled
    # Extracting orientation information from odometry message
    orientation_quaternion = msg.pose.pose.orientation
    orientation_list = [orientation_quaternion.x, orientation_quaternion.y, orientation_quaternion.z, orientation_quaternion.w]
    _, _, yaw = euler_from_quaternion(orientation_list)

    # Assuming the robot is moving in the x direction, update distance traveled
    distance_traveled = msg.pose.pose.position.x

def align_to_aruco():
    rospy.init_node('align_to_aruco', anonymous=True)
    cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)

    #Subscribers for alpha, delta, and odometry messages
    rospy.Subscriber('alpha_error', Float32, alpha_callback)
    rospy.Subscriber('marker_distance', Float32, delta_callback)
    rospy.Subscriber('pose', Odometry, odom_callback)

    twist = Twist()
    rate = rospy.Rate(20)

    # Adjust this value to set the desired angular velocity for orientation adjustment
    angular_velocity = 0.15
    while not rospy.is_shutdown():
        if -1.0 < alpha_error < 1.0:
            twist.angular.z = 0.0  # Stop adjusting orientation
            break
        else:
            # Adjust the orientation with a constant angular velocity
            twist.angular.z = -angular_velocity if alpha_error > 0 else angular_velocity

        cmd_vel_pub.publish(twist)
        rate.sleep()

    # twist.linear.x = 0  # Stop the robot
    twist.angular.z = 0  # Stop adjusting orientation
    cmd_vel_pub.publish(twist)
    rospy.sleep(2)
    # Print the final alignment error and current value of delta
    print('\n-----------------------------------------------')
    print(f"Final Alignment Error: {alpha_error} degrees")
    print(f"Current Value of Delta: {delta_value} degrees")
    print('------------------------------------------------\n')

#    Continue moving forward using odometry feedback
    target_distance = 0.3  # Set the desired distance to 30 centimeters
    linear_velocity = 0.20
    twist.linear.x = linear_velocity

    while (-target_distance <  distance_traveled < target_distance) and not rospy.is_shutdown():
        cmd_vel_pub.publish(twist)
        rate.sleep()

    twist.linear.x = 0  # Stop the robot
    cmd_vel_pub.publish(twist)

#    Print the distance traveled and current value of delta
    print('\n--------------------------------------------')
    print(f"Distance Traveled: {distance_traveled} meters")
    print(f"Current Value of Delta: {delta_value} degrees")
    print('----------------------------------------------\n')
    #rospy.spin()
if __name__ == '__main__':
    try:
        align_to_aruco()
    except rospy.ROSInterruptException:
        pass
