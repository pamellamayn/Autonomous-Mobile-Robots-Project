#!/usr/bin/env python3
import glob
import os
import rospy
import cv2
from sensor_msgs.msg import Joy


class CameraListener:
    def __init__(self) -> None:
        rospy.init_node("capture_images")
        rospy.loginfo("STARTED image capture")
        # clear files in folders we will be using
        self.save_location = "/home/ubuntu/catkin_ws/src/project/scripts/"
        # files = glob.glob(self.save_location+"aruco_images/*") + glob.glob(self.save_location+"undistorted_images/*")
        # for f in files:
        #     os.remove(f)
        self.joy_sub = rospy.Subscriber("joy", Joy, self.joy_callback)
        self.take_image = False
        self.cam = cv2.VideoCapture(0)

    def joy_callback(self, data):
        rospy.loginfo("recived joy data")
        if data.buttons[0] == 1:
            rospy.loginfo("button 0 pressed")
            self.take_image = True

    def take_picture(self):
        i=0
        while not rospy.is_shutdown():
            ret, frame = self.cam.read()
            print(ret, self.take_image)
            if ret and self.take_image:
                ret = cv2.imwrite(self.save_location+f"aruco_images/{i}.jpg", frame)
                rospy.loginfo("saved image") if ret else rospy.loginfo("failed to save image")
                self.take_image = False
                i+=1
            rospy.sleep(.1)
     

if __name__ == '__main__':
    node = CameraListener()
    node.take_picture()
