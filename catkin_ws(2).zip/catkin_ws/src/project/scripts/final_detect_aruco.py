#!/usr/bin/env python3
import glob
import os
import rospy
import cv2 as cv
import math
import numpy as np
from std_msgs.msg import Float32
path_to_scripts = "/home/ubuntu/catkin_ws/src/project/scripts/"
from std_msgs.msg import Int32

aruco_input = 0

def input_callback(msg):
    global aruco_input
    aruco_input = msg.data

class CameraListener:

    def calibrate(self, image):
        chessboard = [9, 6]
        # termination criteria
        criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)
        # prepare object points, like (0,0,0), (1,0,0), (2,0,0) ....,(6,5,0)
        objp = np.zeros((chessboard[0]*chessboard[1],3), np.float32)
        objp[:,:2] = np.mgrid[0:chessboard[0],0:chessboard[1]].T.reshape(-1,2)
        # Arrays to store object points and image points from all the images.
        objpoints = [] # 3d point in real world space
        imgpoints = [] # 2d points in image plane.
        images = glob.glob(image)
        gray = cv.imread(image[0])
        for fname in images:
            img = cv.imread(fname)
            gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
            # Find the chess board corners
            ret, corners = cv.findChessboardCorners(gray, (chessboard[0],chessboard[1]), None)
            # If found, add object points, image points (after refining them)
            if ret == True:
                objpoints.append(objp)
                corners2 = cv.cornerSubPix(gray,corners, (11,11), (-1,-1), criteria)
                imgpoints.append(corners2)
                # Draw and display the corners
                cv.drawChessboardCorners(img, (chessboard[0],chessboard[1]), corners2, ret)
                cv.waitKey(500)
        cv.destroyAllWindows()
        ret, mtx, dist, rvecs, tvecs = cv.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)
        return ret, mtx, dist, rvecs, tvecs

    def __init__(self) -> None:
        rospy.init_node("position_images")
        rospy.loginfo("STARTED image capture")
        rospy.Subscriber('numbers', Int32, input_callback)

        #print('before cam')
        for i in range(20):
            self.cam = cv.VideoCapture(i)
            if self.cam.isOpened():
                ret, frame = self.cam.read()
                if ret:
                    print(f'Camera found at index {i}')
                    break
            self.cam.release()
        #print('after cam')
        self.dictionary = cv.aruco.getPredefinedDictionary(cv.aruco.DICT_4X4_50)
        self.parameters = cv.aruco.DetectorParameters()

        self.error_pub = rospy.Publisher("alpha_error", Float32, queue_size=10)
        self.distance_pub = rospy.Publisher("marker_distance", Float32, queue_size=10)
        self.aruco_pub = rospy.Publisher("aruco_id", Float32, queue_size = 10)
        self.aruco_target_pub = rospy.Publisher("aruco_target", Float32, queue_size = 10)


    def Stream(self):
        #print('In stream')
        alignment_error=10
        distance=10
        calibrate_path = f"{path_to_scripts}chessboard_images/*.jpg"
        self.ret_c, self.mtx_c, self.dist, self.rvecs, self.tvecs = self.calibrate(calibrate_path)
        while not rospy.is_shutdown():
            #print('ros not shutdown')
            ret, frame = self.cam.read()
            #print(f'ret: {ret}')
            if ret:
                #print('in ret')
                corners, ids, rejected = cv.aruco.detectMarkers(frame, self.dictionary, parameters=self.parameters)
                print(f'markers dectected: {ids}')
                if aruco_input == 10:
                     forbid_aruco=20
                elif aruco_input == 20:
                     forbid_aruco=10
                else:
                     forbid_aruco = 0
                if ids is not None:
                      #print('in ids')
                      rvecs, tvecs, _ = cv.aruco.estimatePoseSingleMarkers(corners, 0.1, self.mtx_c, self.dist)
                      print(f'forbinen {forbid_aruco}')

                      for idx, (rvec, tvec) in enumerate(zip(rvecs, tvecs)):
                         if ids[idx][0] == forbid_aruco:
                           print("break")
                           break 
                         if ids[idx][0] != forbid_aruco:
                           print (f'current tag is: {ids[idx]}')
                           #if ids[idx][0]==10:
                           #image = cv.polylines(frame, corners[0].astype(int), True, (0, 255, 0), 2)
                           center = tuple(np.mean(corners[0], axis = 1).astype(int)[0])
                           #cv.putText(image, f"ID: {ids[0][0]}", (10,30), cv.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 2, cv.LINE_AA)
                           alignment_error = self.calculateAlignmentError(center[0])
                           distance = self.calculateDist(tvec)
                           # Publish the alignment error and distance
                           self.error_pub.publish(alignment_error)
                           self.distance_pub.publish(distance)
                           self.aruco_pub.publish(ids[idx][0])

                           print('------------------------------------')
                           print(f'Alignment Error: {alignment_error}')
                           print(f'Distance: {distance}')
                           print(f'Aruco Ids: {ids}')
                           print(f'{forbid_aruco}------------------------------------')
                #cv.imshow("Frame", frame)
                #rospy.loginfo("capturing nad processing") if ret else rospy.loginfo("failed to capture image")
            #rospy.sleep(.1)

    def calculateAlignmentError(self, marker_center):
        frame_width = 640
        horizontal_field_view = 60

        alignment_error = (marker_center-(frame_width/2))/frame_width* horizontal_field_view

        return alignment_error


    def calculateDist(self, tvec):
        print(f'tvec: {tvec}')
        distance_seperation = math.sqrt((tvec[0][0]**2+tvec[0][2]**2))

        return distance_seperation


if __name__ == '__main__':
    node = CameraListener()
    node.Stream()


