#!/usr/bin/env python3
import math
import time
import rospy
import numpy as np
import matplotlib.pyplot as plt
from sensor_msgs.msg import LaserScan
import pandas as pd
from sklearn.cluster import DBSCAN
from math import cos, sin, radians, sqrt
from numpy.linalg import inv
from scipy.signal import find_peaks_cwt, iirfilter, sosfilt, find_peaks
from math import cos, sin, radians, sqrt
from numpy.linalg import inv
from scipy.signal import find_peaks_cwt, iirfilter, sosfilt, find_peaks
import matplotlib.pyplot as plt

def get_line(pt1, pt2):
    if not pt2[0]-pt1[0] == 0:
        slope = (pt2[1]-pt1[1]) / (pt2[0]-pt1[0])
        bias = pt1[1] - slope*pt1[0]
    return [slope, bias]

class Lidar:
    def __init__(self):
        self.first = True
        self.offset = [8.5 * .0254, 0]
        self.get_data = True
        self.data = []
        self.start_time = time.time()

        self.sub = rospy.Subscriber("scan", LaserScan, callback=self.lidar_scan_reciver)


    def one_roatation_plot(self):
        plt.clf()
        df = pd.DataFrame(self.data, columns=['ranges', 'angles'])
        self.data.clear()
        df['X'] = list(map(lambda x, y: cos(x) * y, df['angles'], df['ranges']))
        df['Y'] = list(map(lambda x, y: sin(x) * y, df['angles'], df['ranges']))
        df = df[df['ranges'] < 2]
        df['labels'] = DBSCAN(eps=.10, min_samples=60).fit_predict(list(zip(df['X'], df['Y'])))
        df = df[df['labels'] > -1]

        # Find corners
        corners = df.iloc[find_peaks_cwt(df['ranges'].values, widths=np.arange(200,300))].sort_values(by=['ranges'])
        corners = corners.nlargest(4, 'ranges')
        walls = []
        angles = corners['angles'].tolist()
        print(corners)
        angles.sort()
        #plt.scatter(corners['angles'], corners['ranges'], label='Corners Guess', marker='+', s=160)
        #plt.scatter(df['angles'], df['ranges'], label=f'data', s=1)

        # Find Door corner
        doorc = []
        for i in range(len(df)-1):
            if abs(df.iloc[i]['angles'] - df.iloc[i+1]['angles']) > .05:
                doorc.append(df.iloc[i])
                doorc.append(df.iloc[i+1])
                break
        plt.scatter(doorc[0]['X'], doorc[0]['Y'], label='Door Corner 1', marker='+', s=1600)
        plt.scatter(doorc[1]['X'], doorc[1]['Y'], label='Door Corner 2', marker='+', s=1600)
        print('Door Corner 1 ({}, {})'.format(doorc[0]['X'], doorc[0]['Y']))
        print('Door Corner 2 ({}, {})'.format(doorc[1]['X'], doorc[1]['Y']))

        # Section off walls
        filter_angle = radians(0)
        for i in range(len(corners)):
            if i > (i + 1) % len(corners):
                walls.append(df[(df['angles'] > (angles[i]+filter_angle)) | (df['angles'] < (angles[0])-filter_angle)])
            else:
                walls.append(df[(df['angles'] > (angles[i]+filter_angle)) & (df['angles'] < (angles[i+1])-filter_angle)])

        # Least Squares
        eqs = []

        for i, wall in enumerate(walls):
            plt.scatter(wall['X'], wall['Y'], label=f'Wall {i}', s=1)
            H = np.hstack((np.reshape(wall['X'].to_numpy(), (len(wall),1)), np.ones((len(wall),1))))
            Y = np.reshape(wall['Y'].to_numpy(), (len(wall),1))
            R = np.zeros((len(wall),len(wall)))
            np.fill_diagonal(R, 200)
            tmp = np.dot(np.transpose(H), inv(R))
            tmp = np.dot(tmp, H)
            tmp = inv(tmp)
            tmp = np.dot(tmp, np.transpose(H))
            tmp = np.dot(tmp, inv(R))
            tmp = np.dot(tmp, Y)
            eqs.append((tmp[0][0], tmp[1][0]))
            plt.plot(wall['X'], tmp[0]*wall['X']+tmp[1], label='Wall {} y={}x + {}'.format(i, float(tmp[0]), float(tmp[1])))

        # Calculate door intercept intercept
        # x = b1 -b2 / m2 -m1
        # x = (eqs[1][1] - eqs[2][1]) / (eqs[2][0] - eqs[1][0]) 
        # y = eqs[1][0] * x + eqs[1][1]
        # x = [x]
        # y = [y]
        # plt.scatter(x, y, label='Door Intercept', marker='+', s=1600)

        # Print width of opening
        print('The doorway is', sqrt(pow((doorc[1]['X'] - doorc[0]['X']), 2) + pow((doorc[1]['Y'] - doorc[0]['Y']), 2)), 'm wide')

        plt.legend(prop={'size': 4})
        plt.xticks(np.arange(-1.5, 1.5, .5)) 
        plt.yticks(np.arange(-1.5, 1.5, .5)) 
        plt.savefig('/home/ubuntu/catkin_ws/plot.png')
        df.drop(df.index, inplace=True)
        return
#        x_cords = []
#        y_cords = []
#        points = []
#        for point in self.data:
#            x = math.sin(point[1]) * point[0]
#            y = math.cos(point[1]) * point[0]
#            x_cords.append(x)
#            y_cords.append(y)
#            points.append([x, y])
#
#        dbscan = DBSCAN(eps=.15, min_samples=60)
#        points = np.array(points)
#        labels = dbscan.fit_predict(points)
#        filtered_points = points[labels != -1]
#        points = filtered_points.tolist()
#        points = sorted(points, key=lambda point:math.atan2(point[1], point[0]))
#
#        quadrants = {i: [] for i in range(4)}
#        for idx, pt in enumerate(points):
#            if pt[0] > 0 and pt[1] > 0:
#                quadrants[0].append(idx)
#            elif pt[0] < 0 and pt[1] > 0:
#                quadrants[1].append(idx)
#            elif pt[0] > 0 and pt[1] < 0:
#                quadrants[2].append(idx)
#            elif pt[0] < 0 and pt[1] < 0:
#                quadrants[3].append(idx)
#
#        corners = [quadrants[i][0] for i in range(4)]
#        for quad in quadrants:
#            for pt in quadrants[quad]:
#                if math.dist(points[corners[quad]], [0, 0]) < math.dist(points[pt], [0, 0]):
#                    corners[quad] = int(pt)
#        for corner in corners:
#            plt.plot(points[corner][0],points[corner][1], marker="+", markersize=50)
#    
#        print(corners)
#        max_dist = 0
#        # pts
#        door_openings = [0, 0]
#        for corner in corners:
#            dst1 = math.dist(points[corner], points[corner-1])
#            dst2 = math.dist(points[corner], points[corner+1 if len(points) > corner+1 else 0])
#            if dst1 > dst2:
#                if dst1 > max_dist:
#                    max_dist = dst1
#                    door_openings = [corner, corner-1]
#            else:
#                if dst2 > max_dist:
#                    max_dist = dst2
#                    door_openings = [corner, corner+1 if len(points) > corner+1 else 0]
#        # remove far door corner
#        corners.remove(door_openings[0])
#        corners.sort()
#
#        short_wall_door = door_openings[1]
#        long_wall_door = door_openings[0]
#        if math.dist(points[long_wall_door], points[short_wall_door]) > .5:
#            short_wall_corner = corners[0] 
#            for corner in corners:
#                short_wall_corner = short_wall_corner if math.dist(points[short_wall_door], points[short_wall_corner]) < math.dist(points[short_wall_door], points[corner]) else corner
#            corners.remove(short_wall_corner)
#        
#            long_wall_corner = corners[0] if math.dist(points[long_wall_door], points[corners[0]]) < math.dist(points[long_wall_door], points[corners[1]]) else corners[1]
#            print(short_wall_corner, short_wall_door, long_wall_door, long_wall_corner)
#            print(points[short_wall_door], points[short_wall_corner], points[long_wall_door], points[long_wall_corner])
#            
#            line1 = get_line(points[short_wall_corner], points[short_wall_door])
#            line2 = get_line(points[long_wall_corner], points[long_wall_door])
#            print(f"lines y={line1[0]}x+{line1[1]}, y={line2[0]}x+{line2[1]}")
#            x = (line2[1] - line1[1]) / (line2[0] - line1[0])
#            foundpt = [-x,line1[0]*-x + line1[1]]
#            print("distance: ", math.dist(points[short_wall_door], foundpt))
#            d1 = [points[short_wall_door][0] - self.offset[0], points[short_wall_door][1] - self.offset[1]]
#            d2 = [foundpt[0] - self.offset[0], foundpt[1] - self.offset[1]]
#            print(f"door opening 1: {d1} door opening 2: {d2}")
#
#        plt.scatter(*zip(*points))
#        plt.xlim([-2, 2])
#        plt.ylim([-2, 2])
#        plt.clf()


    def lidar_scan_reciver(self, msg):
        ranges = msg.ranges
        angl = [msg.angle_min + msg.angle_increment*i for i in range(len(msg.ranges))]
        if self.get_data:
            for i in range(len(ranges)):
                if ranges[i] > 0.01:
                    self.data.append([ranges[i], angl[i]])

            if len(self.data) > 10000:
                if not self.first:
                    self.get_data = False
                    print(len(self.data))
                    self.data = self.data[-10000:]
                    self.data = sorted(self.data, key=lambda point:point[1])
                    print(len(self.data))
                    self.one_roatation_plot()
                    self.data.clear()
                    self.start_time = time.time()
                    self.get_data = True
                else:
                    self.first = False


def main():
    rospy.init_node("subscriber_node")
    print("STARTED Subscriber")

    listener = Lidar()
    rospy.spin()

if __name__ == '__main__':
    main()
