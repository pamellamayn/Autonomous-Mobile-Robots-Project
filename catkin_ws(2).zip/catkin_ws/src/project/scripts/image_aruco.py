#!/usr/bin/env python3
import cv2 as cv
import numpy as np
import glob

path_to_scripts = "/home/ubuntu/catkin_ws/src/project/scripts/"

def calibrate(image):
    chessboard = [9, 6]
    # termination criteria
    criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)
    # prepare object points, like (0,0,0), (1,0,0), (2,0,0) ....,(6,5,0)
    objp = np.zeros((chessboard[0]*chessboard[1],3), np.float32)
    objp[:,:2] = np.mgrid[0:chessboard[0],0:chessboard[1]].T.reshape(-1,2)
    # Arrays to store object points and image points from all the images.
    objpoints = [] # 3d point in real world space
    imgpoints = [] # 2d points in image plane.
    images = glob.glob(image)
    gray = cv.imread(image[0])
    for fname in images:
        img = cv.imread(fname)
        gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        # Find the chess board corners
        ret, corners = cv.findChessboardCorners(gray, (chessboard[0],chessboard[1]), None)
        # If found, add object points, image points (after refining them)
        if ret == True:
            objpoints.append(objp)
            corners2 = cv.cornerSubPix(gray,corners, (11,11), (-1,-1), criteria)
            imgpoints.append(corners2)
            # Draw and display the corners
            cv.drawChessboardCorners(img, (chessboard[0],chessboard[1]), corners2, ret)
            cv.waitKey(500)
    cv.destroyAllWindows()
    ret, mtx, dist, rvecs, tvecs = cv.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)
    print('Camera Calabration')
    for row in dist:
        print(f'\t{row}')
    return ret, mtx, dist, rvecs, tvecs

calibrate_path = f"{path_to_scripts}chessboard_images/*.jpg"
aruco_path = f"{path_to_scripts}aruco_images/*.jpg"

ret, mtx, dist, rvecs, tvecs = calibrate(calibrate_path)

# this should be a set of already cv.imread(image)
images = glob.glob(aruco_path)

# load everything needed for the detector
dictionary = cv.aruco.getPredefinedDictionary(cv.aruco.DICT_4X4_50)
parameters = cv.aruco.DetectorParameters()



for idx, image_path in enumerate(images):
    out_path = image_path.replace('aruco_images', 'output_images')
    image = cv.imread(image_path)
    corners, ids, reject = cv.aruco.detectMarkers(image, dictionary, parameters=parameters)
    # find all aruco corners and ids in the image using detector
    rotation, translation, _ = cv.aruco.estimatePoseSingleMarkers(corners, .1, mtx, dist)
    #Draw the boundary box
    if ids != None:
        image = cv.polylines(image, corners[0].astype(int), True, (0, 255, 0), 2)
    #draw the cent of the marker
        center = tuple(np.mean(corners[0], axis = 1).astype(int)[0])
        print (translation)
   #display the id at the left top of the image
        cv.putText(image, f"ID: {ids[0][0]}", (10,30), cv.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 2, cv.LINE_AA)
        cv.imwrite(out_path, image)

    print('------------------------------------')
    print(f'Image Path: {image_path}')
    print(f'Rotation Vector: {rotation}')
    print(f'Translation Vectors: {translation}')
    print('------------------------------------')
