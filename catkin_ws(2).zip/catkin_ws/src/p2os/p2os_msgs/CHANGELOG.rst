^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package p2os_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.0 (2019-03-14)
------------------
* Update email address (`#58 <https://github.com/allenh1/p2os/issues/58>`_)
* Contributors: Hunter L. Allen

2.2.1 (2020-06-18)
------------------
* Prepare release 2.2.0 (`#59 <https://github.com/allenh1/p2os/issues/59>`_)
  * Update changelog
  * 2.2.0
* Update email address (`#58 <https://github.com/allenh1/p2os/issues/58>`_)
* Contributors: Hunter L. Allen

2.1.1 (2018-07-03)
------------------

2.1.0 (2017-08-01)
------------------
* Switch to format 2 (`#48 <https://github.com/allenh1/p2os/issues/48>`_)
  * Update p2os_launch to package.xml format 2.
  * Update p2os_driver to package.xml format 2.
  * Update p2os_urdf to package.xml format 2.
  * Update p2os_teleop package.xml to format 2.
  * Update p2os_msgs to package.xml format 2.
  * Update p2os_doc to package.xml format 2.
* Contributors: Hunter Allen

2.0.7 (2017-05-30)
------------------
* Updated changelog.
* merged.
* Updated package metadata, as well as added the correct c++ flags to the urdf file (for Gentoo support).
* Contributors: Hunter L. Allen

* merged.
* Updated package metadata, as well as added the correct c++ flags to the urdf file (for Gentoo support).
* Contributors: Hunter L. Allen

2.0.6 (2017-05-22)
------------------

2.0.5 (2016-05-26)
------------------

2.0.4 (2016-05-26)
------------------

2.0.3 (2015-10-25)
------------------

2.0.2 (2015-08-04)
------------------

2.0.1 (2015-07-11)
------------------

1.0.13 (2015-05-02)
-------------------

1.0.12 (2014-06-25)
-------------------
* Updated to match indigo-devel
* Fixed dependency issues and cleaned up package.xml and CMakeLists.txt for p2os_driver and p2os_msgs
* Separated p2os_driver and p2os_msgs
* Contributors: Aris Synodinos, Hunter Allen

1.0.11 (2014-06-25)
-------------------
* Fixed dependency issues and cleaned up package.xml and CMakeLists.txt for p2os_driver and p2os_msgs
* Separated p2os_driver and p2os_msgs
* Contributors: Aris Synodinos

1.0.10 (2014-05-28)
-------------------

1.0.9 (2013-08-18)
------------------

1.0.7 (2013-08-03)
------------------

1.0.6 (2013-07-27)
------------------

1.0.5 (2013-07-23 16:31)
------------------------

1.0.4 (2013-07-23 14:32)
------------------------

1.0.2 (2013-07-23 09:17)
------------------------

1.0.1 (2013-07-22)
------------------

1.0.0 (2013-06-18 12:26)
------------------------
