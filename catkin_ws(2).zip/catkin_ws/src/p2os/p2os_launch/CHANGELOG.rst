^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package p2os_launch
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.0 (2019-03-14)
------------------
* Update email address (`#58 <https://github.com/allenh1/p2os/issues/58>`_)
* Contributors: Hunter L. Allen

2.2.1 (2020-06-18)
------------------
* Prepare release 2.2.0 (`#59 <https://github.com/allenh1/p2os/issues/59>`_)
  * Update changelog
  * 2.2.0
* Update email address (`#58 <https://github.com/allenh1/p2os/issues/58>`_)
* Contributors: Hunter L. Allen

2.1.1 (2018-07-03)
------------------

2.1.0 (2017-08-01)
------------------
* Switch to format 2 (`#48 <https://github.com/allenh1/p2os/issues/48>`_)
  * Update p2os_launch to package.xml format 2.
  * Update p2os_driver to package.xml format 2.
  * Update p2os_urdf to package.xml format 2.
  * Update p2os_teleop package.xml to format 2.
  * Update p2os_msgs to package.xml format 2.
  * Update p2os_doc to package.xml format 2.
* Contributors: Hunter Allen

2.0.7 (2017-05-30)
------------------
* Updated changelog.
* merged.
* Updated package metadata, as well as added the correct c++ flags to the urdf file (for Gentoo support).
* Contributors: Hunter L. Allen

* merged.
* Updated package metadata, as well as added the correct c++ flags to the urdf file (for Gentoo support).
* Contributors: Hunter L. Allen

2.0.6 (2017-05-22)
------------------
* Added an enable motors launch file.
* Contributors: Hunter L. Allen

2.0.5 (2016-05-26)
------------------

2.0.4 (2016-05-26)
------------------

2.0.3 (2015-10-25)
------------------

2.0.2 (2015-08-04)
------------------

2.0.1 (2015-07-11)
------------------
* Doing some cleanup of the code.
* Contributors: Hunter Allen

1.0.13 (2015-05-02)
-------------------
* Oops. Should have caught that by now probably.
* Contributors: Hunter Allen

1.0.12 (2014-06-25)
-------------------
* Updated to match indigo-devel
* General cleanup and fixing issues with the code
* Contributors: Aris Synodinos, Hunter Allen

1.0.11 (2014-06-25)
-------------------

1.0.10 (2014-05-28)
-------------------

1.0.9 (2013-08-18)
------------------
* Updated version
* 1.0.7
* Updated changelogs
* Updated the launch files

1.0.7 (2013-08-18)
------------------
* Updated the launch files

* Updated to match hmt-git.com repository

1.0.5 (2013-07-23)
------------------

* Added new navigation files
* Added new launch files
* Updated to match hmt-git.com

* Updated to hmt-git.com repo

1.0.1 (2013-07-22)
------------------
* Updating to match hmt-git.com repo
* Removed a line
* Updated p2os_launch for catkin
* Removed build directory.
* Added a new launch file
* added the code
